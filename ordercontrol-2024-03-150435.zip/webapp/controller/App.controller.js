sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.lab2dev.ordercontrol.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  
sap.ui.define([
	"comlab2dev/ordercontrol/test/unit/controller/OrderControl.controller"
], function () {
	"use strict";
});

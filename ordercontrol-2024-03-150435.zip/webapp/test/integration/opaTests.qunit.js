/* global QUnit */

sap.ui.require(["com/lab2dev/ordercontrol/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
